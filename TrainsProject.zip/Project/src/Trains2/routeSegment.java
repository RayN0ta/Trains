package Trains2;

public class routeSegment
{

    public Train train;
    public ArrList<Station> stops;

    public routeSegment(Train t)
    {
        this.train = t;
        this.stops = new ArrList<Station>();
    }

    public void addStop(Station s)
    {
        this.stops.add(s);
    }

    public String toString()
    {
        String res;
        res = "[" + this.train.id + "]=>\n";
        for (int k = 0; k < stops.size(); k++)
        {
            res += ":" + stops.get(k);
        }
        return res;
    }

}
