package Trains2;

import java.util.*;
import java.io.*;
import java.util.Scanner;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class tools
{
// #############################################
    public static ArrList<List<String>> readFromFile( String filename )
    {
     ArrList<List<String>> list = new ArrList<List<String>>();

     try
        {
        Scanner s = new Scanner(new File(System.getProperty("user.dir") + "/" + filename));
        while (s.hasNext()){
            String str = s.next();
            List<String> A = Arrays.asList(str.split(",") );
            list.add(A);
        }
        s.close();
        }
     catch (FileNotFoundException ex)
        {
            System.out.println("File " + System.getProperty("user.dir") + "/" + filename + " NOT FOUND!!!" );
        }

        return(list);
    }

// #############################################

    public static ArrList<Station>  loadStationsFromFile ( String filename ) {

          ArrList<List<String>> stations = tools.readFromFile( filename );

          ArrList<Station> stationsList = new ArrList<>();

          for ( int k = 0; k < stations.size(); k++)
          {
            List<String> dd = stations.get(k);
            Station s = new Station(dd.get(0), dd.get(1));
            stationsList.add(s);
          }

          return(stationsList);

    }

// #############################################


    public static ArrList<Train>  loadTrainsFromFile ( String filename, ArrList<Station> stations) {
          ArrList<List<String>> trains = tools.readFromFile( filename );

          ArrList<Train> trainsList = new ArrList<>();

          for ( int k = 0; k < trains.size(); k++)
          {
            List<String> dd = trains.get(k);
            Train t = new Train(dd.get(0), dd.get(1));
            t.setStops(dd.get(2), dd.get(3),dd.get(4), stations);
            trainsList.add(t);
          }

          return(trainsList);

    }

// #############################################

    public static void saveTrainsToFile (ArrList<Train> Trains, String filename)
    {

        try (PrintWriter out = new PrintWriter( System.getProperty("user.dir") + "/" + filename )) {

        for (int k = 0; k < Trains.size(); k++)
        {
            Train t = Trains.get(k);
            out.println( String.join(",", t.id, t.name, t.from.id, t.to.id, Train.stopsIDToString(t.stopsIDToList() ) ) );
        }


         out.close();
        }
        catch (FileNotFoundException ex)
        {
            System.out.println("File " + System.getProperty("user.dir") + "/" + filename + " CAN'T WRITE!!!" );
        }

    }

// #############################################

public static void saveStationsToFile (ArrList<Station> Stations, String filename)
    {

        try (PrintWriter out = new PrintWriter( System.getProperty("user.dir") + "/" + filename )) {

        for (int k = 0; k < Stations.size(); k++)
        {
            Station t = Stations.get(k);
            out.println( String.join(",", t.id, t.name));
        }


         out.close();
        }
        catch (FileNotFoundException ex)
        {
            System.out.println("File " + System.getProperty("user.dir") + "/" + filename + " CAN'T WRITE!!!" );
        }

    }

// #############################################

    public static ArrList<Integer> InsertionSortInt(ArrList<Integer> arr)
    {
        Integer n = arr.size();
        for (Integer i = 1; i < n; ++i) {
            Integer key = arr.get(i);
            Integer j = i - 1;
            while (j >= 0 && arr.get(j) > key) {
                arr.set(j + 1, arr.get(j));
                j = j - 1;
            }
            arr.set(j + 1, key);
        }
        return(arr);
    }

// #############################################

    public static String[][] dataFromTable (JTable table)
    {
        DefaultTableModel model = (DefaultTableModel) table.getModel();

        String[][] res = new String[model.getRowCount()][model.getColumnCount()];

        for (int row = 0; row < model.getRowCount(); row++) {
                for (int col = 0; col < model.getColumnCount(); col++) {
                    res[row][col] = model.getValueAt(row, col).toString();
                }
            }
        return res;
    }

// #############################################
}