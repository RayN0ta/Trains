package Trains2;

import java.util.Arrays;
import java.util.List;

public class Train {

    public String id = "";
    public String name = "";
    public Station from = null;
    public Station to = null;
    public ArrList<Station> stops = null;

// #############################################

    public Train()
    {
        this.id    = null;
        this.name  = null;
    }

// #############################################

    public Train(String id, String name)
    {
        this.id    = id;
        this.name  = name;
    }

// #############################################

    public void setStops(String from, String to, String stopsString, ArrList<Station> list)
    {

        Station s = new Station();
        this.from  = s.findWithID(from, list);
        this.to    = s.findWithID(to, list);
        this.stops = stopsFromList( stopsIDFromString(stopsString), list );
    }
// #############################################

    public String toString()
    {
        return("[" + this.id + "]" + this.name + "|" + this.from.id + "->" + this.to.id + "|" + "(" +  stopsIDToString( this.stopsIDToList() ) + ")\n");
    }

// #############################################

    private ArrList<Station> stopsFromList( List<String> stopsID, ArrList<Station> list)
    {
        ArrList<Station> stops = new ArrList<>();

        for (int k = 0; k < stopsID.size(); k++)
        {
            Station s = new Station();
            stops.add(s.findWithID(stopsID.get(k), list));

        }
        return(stops);
    }

// #############################################

    public ArrList<String> stopsIDToList()
    {
        ArrList<String> list = new ArrList<>();

        for ( int k = 0; k < this.stops.size(); k++)
        {
            Station st = this.stops.get(k);
            list.add(st.id);
        }
        return(list);
    }

// #############################################

    private static List<String> stopsIDFromString( String str )
    {
        return(  Arrays.asList(str.split(":")) );
    }

// #############################################
    public static String stopsIDToString( ArrList<String> list)
    {
        String res = list.get(0);
        for(int k = 1; k < list.size(); k++)
        {
            res += ":" + list.get(k);
        }
        return( res );
    }

// #############################################

    public boolean passBy(String stationID)
    {
        for (int k=1; k < this.stops.size(); k++)
        {
            Station s = this.stops.get(k);
            if ( stationID.equals(s.id) )
            {
            return(true);
            }
        }
        return(false);
    }

// #############################################
    public boolean addStation(Station s, int index)
    {
        if (index < 0) index = this.stops.size();

        this.stops.add(index, s);

        if ( index == this.stops.size() - 1 )
        {
            this.to = s;
        }
        if ( index == 0 )
        {
            this.from = s;
        }
        return true;
    }

// #############################################

    public int getStopsCount()
    {
        return this.stops.size();
    }

// #############################################

    public int getStopIndex(Station s)
    {
        for(int k = 0; k < this.stops.size(); k++)
        {
            if( this.stops.get(k).id == s.id )
            {
                return(k);
            }
        }
        return(-1);
    }

// #############################################

}
