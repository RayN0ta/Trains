package Trains2;

import javax.swing.*;

import javax.swing.table.DefaultTableModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JOptionPane;
import javax.swing.table.*;
import java.util.Comparator;

import java.util.ArrayList; // Used only for compatibility with tables.



import java.awt.event.*;
import java.awt.*;

public class TrainsMain 
{

	public static void main(String[] args) 
	{
		// ########### MAIN FRAME ###############
        JFrame mainFrame = new JFrame("Vassa TRAINS");
        mainFrame.setSize(130, 350);
        
        mainFrame.getContentPane().setBackground(Color.decode("#5FB49C"));

        JButton TrainsBtn = new JButton("Trains");
        TrainsBtn.setBounds(10, 20, 100, 50);
        
        JButton StationsBtn = new JButton("Stations");
        StationsBtn.setBounds(10, 80, 100, 50);

        JButton RouteBtn = new JButton("Route");
        RouteBtn.setBounds(10, 140, 100, 50);

        JButton LoadBtn = new JButton("Load");
        LoadBtn.setBounds(10, 200, 100, 50);

        JButton SaveBtn = new JButton("Save");
        SaveBtn.setBounds(10, 260, 100, 50);

        mainFrame.add(TrainsBtn);
        mainFrame.add(StationsBtn);
        mainFrame.add(RouteBtn);
        mainFrame.add(LoadBtn);
        mainFrame.add(SaveBtn);

        ArrList<Station> stationsList = tools.loadStationsFromFile("stations.txt");
        ArrList<Train> trainsList = tools.loadTrainsFromFile("trains.txt", stationsList);
        TrainManager TM = new TrainManager(stationsList, trainsList);


        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setLayout(null);
        mainFrame.setVisible(true);

        // ############ ACTION LISTENERS ###########

        LoadBtn.addActionListener(new ActionListener() 
        {

            @Override
            public void actionPerformed(ActionEvent e) 
            {

                 System.out.println("LoadBtn Pressed");

                ArrList<Station> stationsList = tools.loadStationsFromFile("stations.txt");
                ArrList<Train> trainsList = tools.loadTrainsFromFile("trains.txt", stationsList);

                TrainManager TM = new TrainManager(stationsList, trainsList);
               System.out.println("Data loaded" + TM);

            }
        });

        // ##############

        SaveBtn.addActionListener(new ActionListener() 
        {

            @Override
            public void actionPerformed(ActionEvent e) 
            {

               System.out.println("SaveBtn Pressed");

               tools.saveTrainsToFile(TM.getTrains(), "trains_out.txt");
               tools.saveStationsToFile(TM.getStations(), "stations_out.txt");
               System.out.println("\n\n Data saved\n" + TM);

            }
        });

        // ##############

         StationsBtn.addActionListener(new ActionListener() 
         {

            @Override
            public void actionPerformed(ActionEvent e) 
            {

                 System.out.println("StationsBtn Pressed");

                 JFrame SFrame = new JFrame("Stations");

                 ArrList<Station> ST = TM.getStations();

                 String[] colnames = {"ID", "Name"};

                 DefaultTableModel model = new DefaultTableModel(colnames, 0)
                 {
                       @Override
                        public boolean isCellEditable(int row, int column) 
                       {
                            return column != 0;
                       }
                 };

                for (int k = 0; k < ST.size(); k++)
                 {
                    Station s = ST.get(k);
                    model.addRow(new Object[]{s.id, s.name});
                 }

                JTable STable = new JTable(model);
                STable.setShowGrid(true);
                STable.setGridColor(Color.BLACK);

                TableRowSorter<TableModel> sorter = new TableRowSorter<>(model);
                STable.setRowSorter(sorter);
                JScrollPane scrollPane = new JScrollPane(STable);

                JPopupMenu popupMenu = new JPopupMenu();
                JMenuItem delItem = new JMenuItem("Delete row");
                JMenuItem addItem = new JMenuItem("Add row");
                JMenuItem saveItem = new JMenuItem("Save");

				popupMenu.add(delItem);
                popupMenu.add(addItem);
                popupMenu.add(saveItem);

                addItem.addActionListener(e1 -> {
                            model.addRow(new Object[]{"", ""});
                        });

                saveItem.addActionListener(e2 -> {

                    String[][] data = tools.dataFromTable(STable);
                    for (int row = 0; row < data.length; row++) 
                    {
                        String[] r = data[row];

                        Station s = TM.getStation( r[0].toString() );

                        if ( s == null ) 
                        {
                            TM.addStation( new  Station( "s" + (TM.Stations.size() + 1), r[1].toString()) );
                        }
                        else
                        {
                            s.name = r[1];
                        }
                     }

                 });

                delItem.addActionListener(e2 -> {
							int sr = STable.getSelectedRow();

							if (sr < 0) return;

							String sID = STable.getValueAt(sr,0).toString();

							Station s = TM.getStation( sID );
							int index = TM.getStationIndex( s );

							//showMessageDialog
							int q = JOptionPane.showConfirmDialog(
								null,
								"Delete station " + s.toString(),
								"Are you shure!",
								JOptionPane.YES_NO_OPTION,
								JOptionPane.ERROR_MESSAGE
							);


							if ( q == JOptionPane.YES_OPTION )
							{
								if ( TM.trainsByStation(s.id).size() > 0 )
								{
									JOptionPane.showMessageDialog(
										null,
										"There is a train passing by. Can not be deleted!",
										"Error",
										JOptionPane.ERROR_MESSAGE
									);
								}
								else 
								{
									model.removeRow(STable.getSelectedRow());
									TM.Stations.remove(index);
									System.out.println("DELETE --- "+ sID + "==== " + q);
								}
							}
							else 
							{
								System.out.println("DELETE Canceled "+ sID + "==== " + q);
							}
                        });


                STable.addMouseListener(new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent e1) 
                {
                    showPopup(e1);
                }

                @Override
                public void mouseReleased(MouseEvent e1) 
                {
                    showPopup(e1);
                }

                private void showPopup(MouseEvent e) 
                {
                    if (e.isPopupTrigger()) 
                    { // Right-click on different OS
                        popupMenu.show(e.getComponent(), e.getX(), e.getY());
                    }
                }
                });

                SFrame.add(scrollPane);
                SFrame.setSize(200, 300);
                SFrame.setLocationRelativeTo(null);
                SFrame.setVisible(true);
            }
        });

        // ##############


         TrainsBtn.addActionListener(new ActionListener() 
         {

            @Override
            public void actionPerformed(ActionEvent e) 
            {

                 System.out.println("TrainsBtn Pressed");

                 JFrame TFrame = new JFrame("Trains");
               
                 ArrList<Train> TR = TM.getTrains();

                 String[] colnames = {"ID", "Name", "From", "To", "Stops"};

                 DefaultTableModel model = new DefaultTableModel(colnames, 0)
                 {
                       @Override
                        public boolean isCellEditable(int row, int column) 
                       {
                            return column != 0;
                       }
                 };

                for (int k = 0; k < TR.size(); k++)
                 {
                    Train t = TR.get(k);
                    model.addRow(new Object[]{t.id, t.name, t.from.id, t.to.id, t.stopsIDToString( t.stopsIDToList() ) });
                 }

                JButton srtByFS = new JButton("Sort by first stop");
                JButton srtBySC = new JButton("Sort by number of stops");

                Color buttonColor = Color.decode("#5FB49C");

                for (JButton btn : new JButton[]{srtByFS, srtBySC})
                {
                    btn.setBackground(buttonColor);
                    btn.setForeground(Color.BLACK);
                    btn.setFocusPainted(false);
                    btn.setFont(new Font("SansSerif", Font.BOLD, 12));
                    btn.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
                }


                JPanel btnPanel = new JPanel();
                btnPanel.setBackground(Color.decode("#DEEFB7"));
                btnPanel.add(srtByFS);
                btnPanel.add(srtBySC);
               
                JTable TTable = new JTable(model);
                TTable.setBackground(Color.decode("#DEEFB7"));       
                TTable.setForeground(Color.decode("#222222"));        
                TTable.setGridColor(Color.GRAY);                      
                TTable.setSelectionBackground(Color.decode("#A3D9A5")); 
                TTable.setSelectionForeground(Color.BLACK);
                TTable.setRowHeight(24);
                TTable.setFont(new Font("SansSerif", Font.PLAIN, 13));
                TTable.setShowGrid(true);
                TTable.setGridColor(Color.BLACK);
                
                JTableHeader header = TTable.getTableHeader();
                header.setBackground(Color.decode("#5FB49C"));        
                header.setForeground(Color.WHITE);
                header.setFont(new Font("SansSerif", Font.BOLD, 14));

                TableRowSorter<TableModel> sorter = new TableRowSorter<>(model);
                TTable.setRowSorter(sorter);


                Comparator<String> compareTrainsByFirstStation = new Comparator<String>() {
                    public int compare(String a, String b)
                    {
                        if (a.equals("") || b.equals("") ) return -1;
                        return TM.compareTrainsByFirstStation(a, b);
                    }
                };


                Comparator<String> compareTrainsByStops = new Comparator<String>() {
                    public int compare(String a, String b)
                    {
                        if (a.equals("") || b.equals("") ) return -1;
                        return TM.compareTrainsByStops(a, b);
                    }
                };



                srtByFS.addActionListener(new ActionListener() 
                {
                    public void actionPerformed(ActionEvent e) 
                    {
                        sorter.setComparator(0, compareTrainsByFirstStation);
                        java.util.List<RowSorter.SortKey> sortKeys = new java.util.ArrayList<RowSorter.SortKey>();
                        sortKeys.add(new RowSorter.SortKey(0, SortOrder.ASCENDING));
                        sorter.setSortKeys(sortKeys);
                    }
                });

                srtBySC.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) 
                    {
                        sorter.setComparator(0, compareTrainsByStops);
                        java.util.List<RowSorter.SortKey> sortKeys = new java.util.ArrayList<RowSorter.SortKey>();
                        sortKeys.add(new RowSorter.SortKey(1, SortOrder.ASCENDING));
                        sorter.setSortKeys(sortKeys);
                    }
                });


                JScrollPane scrollPane = new JScrollPane(TTable);

                JPopupMenu popupMenu = new JPopupMenu();
                JMenuItem delItem = new JMenuItem("Delete row");
                JMenuItem addItem = new JMenuItem("Add row");
                JMenuItem saveItem = new JMenuItem("Save");

				popupMenu.add(delItem);
                popupMenu.add(addItem);
                popupMenu.add(saveItem);

                addItem.addActionListener(e1 -> {
                            model.addRow(new Object[]{"", "","","",""});
                        });

                saveItem.addActionListener(e2 -> {
                    String[][] data = tools.dataFromTable(TTable);
                    for (int row = 0; row < data.length; row++) 
                    {
                        String[] r = data[row];

                        int i = TM.checkTrainData(r[2].toString(), r[3].toString(), r[4].toString());

                        if (i != 0)
                        {

                        System.out.println("EROOR = " + i);
                            String msg = new String();
                            if ( i == -1) msg = "From station missing";
                            if ( i == -2) msg = "To station missing";

                            if ( i > 0) msg = "Stos " + i + " missing";
                            JOptionPane.showMessageDialog(
										null,
										msg,
										"Error",
										JOptionPane.ERROR_MESSAGE
									);
                        }
                        else
                        {
                            Train t = TM.getTrain( r[0].toString() );

                            if ( t == null ) 
                            {
                                t = new  Train( "t" + (TM.Trains.size() + 1), r[1].toString());
                                TM.addTrain(t);
                            }
                            else
                            {
                                t.name = r[1];
                            }
                            t.setStops(r[2].toString(), r[3].toString(), r[4].toString(), TM.Stations);
                        }
                     }

                });

                delItem.addActionListener(e2 -> {
							int sr = TTable.getSelectedRow();
							String tID = TTable.getValueAt(sr,0).toString();

                            Train t = TM.getTrain( tID );
							int index = TM.getTrainIndex( t );

							//showMessageDialog
							int q = JOptionPane.showConfirmDialog(
								null,
								"Delete train " + t.toString(),
								"Are you shure!",
								JOptionPane.YES_NO_OPTION,
								JOptionPane.ERROR_MESSAGE
							);


							if ( q == JOptionPane.YES_OPTION )
							{
								model.removeRow(TTable.getSelectedRow());
								TM.Trains.remove(index);
								System.out.println("DELETE --- "+ t.toString() );
							}
							else 
							{
								System.out.println("DELETE Canceled ");
							}
                        });


                TTable.addMouseListener(new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent ee1) 
                {
                    showPopup(ee1);
                }

                @Override
                public void mouseReleased(MouseEvent ee1) 
                {
                    showPopup(ee1);
                }

                private void showPopup(MouseEvent ee) 
                {
                    if (ee.isPopupTrigger()) { // Right-click on different OS
                        popupMenu.show(ee.getComponent(), ee.getX(), ee.getY());
                    }
                }
                });

                TFrame.setLayout(new BorderLayout());
                TFrame.add(scrollPane, BorderLayout.CENTER);
                TFrame.add(btnPanel, BorderLayout.SOUTH);
                TFrame.setSize(500, 300);
                TFrame.setLocationRelativeTo(null);
                TFrame.setVisible(true);
            }
        });

        // ##############


         RouteBtn.addActionListener(new ActionListener() {
          @Override
            public void actionPerformed(ActionEvent e)
            {

                 System.out.println("RouteBtn Pressed");

                 JTextField fromFld = new JTextField(10);
                 JTextField toFld   = new JTextField(10);
                 JButton sBtn    = new JButton("Search");

                 DefaultTableModel tableModel = new DefaultTableModel(new Object[]{"Train", "Stop"}, 0);

                 sBtn.addActionListener(e5 -> {


                    String from = fromFld.getText().trim();
                    String to = toFld.getText().trim();

                    Station Sfrom = TM.getStation(from);
                    Station Sto   = TM.getStation(to);

                    if ( Sfrom == null )
                    {
                       JOptionPane.showMessageDialog(
										null,
										"Station from does not exixts",
										"Error",
										JOptionPane.ERROR_MESSAGE
									);
						return;

                    }

                    if ( Sto == null )
                    {
                       JOptionPane.showMessageDialog(
										null,
										"Station to does not exixts",
										"Error",
										JOptionPane.ERROR_MESSAGE
									);
                        return;
                    }

                    ArrList<routeSegment> Route = TM.getRoute(Sfrom, Sto);
                    System.out.println(Route);

                    tableModel.setRowCount(0);

                    if (Route == null)
                    {

                        JOptionPane.showMessageDialog(
										null,
										"No route found",
										"Error",
										JOptionPane.ERROR_MESSAGE
						);
                        return;
                    }

                    for (int k = 0; k < Route.size(); k++)
                    {
                        routeSegment segment = Route.get(k);

                        System.out.println(segment);

                        tableModel.addRow(new Object[]{segment.train.toString(), segment.stops.get(0).toString()});
                        for (int l = 1; l < segment.stops.size(); l++)
                        {
                            tableModel.addRow(new Object[]{"", segment.stops.get(l).toString()});
                        }
                    }



                });

                 JPanel Panel = new JPanel();
                 Panel.setLayout(new BoxLayout(Panel, BoxLayout.Y_AXIS));

                 JPanel row1 = new JPanel(new FlowLayout(FlowLayout.RIGHT));
                 row1.add(new JLabel("From:"));
                 row1.add(fromFld);

                 JPanel row2 = new JPanel(new FlowLayout(FlowLayout.RIGHT));
                 row2.add(new JLabel("To:"));
                 row2.add(toFld);

                 JPanel row3 = new JPanel(new FlowLayout(FlowLayout.RIGHT));
                 row3.add(sBtn);

                 Panel.add(row1);
                 Panel.add(row2);
                 Panel.add(row3);

                 JTable RTable = new JTable(tableModel);
                 RTable.setShowGrid(true);
                 RTable.setGridColor(Color.BLACK);
                 JScrollPane scrollPane = new JScrollPane(RTable);


                 JFrame RFrame = new JFrame("Route");
                 RFrame.add(Panel, BorderLayout.NORTH);
                 RFrame.add(scrollPane, BorderLayout.CENTER);
                 RFrame.setSize(200, 300);
                 RFrame.setLocationRelativeTo(null);
                 RFrame.setVisible(true);

            }
        });

	}

}
