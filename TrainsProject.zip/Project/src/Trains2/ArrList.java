package Trains2;

import java.util.Arrays;

public class ArrList<T>
{
	private T[] list;
	private int numberOfElements;

// ####################################
    public ArrList()
    {
        this.list = (T[]) new Object[10];
        this.numberOfElements = 0;
    }

// ####################################
	public void add(T el)
	{
		if (numberOfElements == this.list.length) doubleListSize();
		this.list[numberOfElements]=el;
		this.numberOfElements++;
	}

// ####################################
	public void add(int index, T el)
	{
		if(index < 0 || index > this.numberOfElements)
			throw new IndexOutOfBoundsException(String.format("Index out of bounds: index: %d, size: %d", index, this.numberOfElements));

		if (numberOfElements == this.list.length) doubleListSize();
		for (int i = this.numberOfElements; i > index; i--)
		{
			this.list[i]=this.list[i-1];
		}
		this.list[index]=el;
		this.numberOfElements++;
	}

// ####################################
	public T get(int index)
	{
		if (index<0 || index >= this.numberOfElements)
			throw new IndexOutOfBoundsException(String.format("Index out of bounds: index: %d, size: %d", index, this.numberOfElements));
		return (this.list[index]);
	}

// ####################################

	public int set(int index, T el)
	{
		if(index < 0 || index >= this.numberOfElements)
			throw new IndexOutOfBoundsException(String.format("Index out of bounds: index: %d, size: %d", index, this.numberOfElements));

		this.list[index]=el;
		return( index );
	}

// ####################################

	public int size()
	{
	    return(this.numberOfElements);
	}

// ####################################

	private void doubleListSize()
	{
		T[] temp = this.list;
		list=(T[]) new Object[this.list.length*2];

		for (int i = 0; i < temp.length; i++) {
			this.list[i]=temp[i];
		}

		temp=null;
		System.gc();
	}

// ####################################

	public String toString()
	{
		T[] temp=Arrays.copyOf(this.list, this.numberOfElements);
		String result=Arrays.toString(temp);
		temp=null;
		System.gc();
		return(result);
	}

// ####################################
    public void remove(int index)
    {
        for (int k = index; k < this.numberOfElements; k++)
        {
            this.list[k] = this.list[k+1];
        }
        this.list[ this.numberOfElements ] = null;
        this.numberOfElements--;
    }
}

