package Trains2;

public class Station {

    public String id = "";
    public String name = "";

// #############################################

    public Station()
    {
        this.id = null;
        this.name = null;
    }


// #############################################

    public Station(String id, String name)
    {
        this.id = id;
        this.name = name;
    }

// #############################################
    public String toString()
    {
        return "[" + this.id + "] - " + this.name + "\n";
    }

// #############################################
    public Station findWithID( String id, ArrList<Station> list )
    {
        for (int k = 0; k < list.size(); k++) {
            Station cs = list.get(k);
            if ( id.equals(cs.id) ) {
                return cs;
            }
        }
        return null;
    }
}
