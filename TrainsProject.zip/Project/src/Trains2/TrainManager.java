package Trains2;

import java.util.Arrays;
import java.util.List;

public class TrainManager
{

    public ArrList<Station> Stations = null;
    public ArrList<Train>   Trains = null;

// #############################################

    public TrainManager(ArrList<Station> Stations, ArrList<Train> Trains)
    {
        this.Stations = Stations;
        this.Trains   = Trains;
    }

// #############################################

    public ArrList<Train> getTrains()
    {
        return this.Trains;
    }
// #############################################

    public ArrList<Station> getStations()
    {
        return this.Stations;
    }


// #############################################
    public String toString()
    {
        return( this.Stations.toString() + "\n" + this.Trains.toString() );
    }


// #############################################
    public ArrList<Train> trainsByStation(String StationID)
    {
        ArrList<Train> tr = new ArrList<>();
        for (int k=0; k < this.Trains.size(); k++)
        {
            Train t = this.Trains.get(k);
            if ( t.passBy(StationID) ) {
                tr.add(t);
            }
        }
         return(tr);
    }

// #############################################

    public ArrList<Station> commonStation(Train t1, Train t2)
    {
        ArrList<Station> res = new ArrList<>();
        ArrList<Station> S1 = t1.stops;
        for (int k = 0; k < S1.size(); k++)
        {
            Station cs = S1.get(k);
            if ( t2.passBy(cs.id) ){
                res.add(cs);
            }
        }
        return(res);
    }

// #############################################

    public void addTrain( Train t)
    {
        this.Trains.add(t);
    }
// #############################################

    public void addStation( Station s)
    {
        this.Stations.add(s);
    }

// #############################################

    public void removeTrain( Train t )
    {
        int i = this.getTrainIndex( t );
        this.Trains.remove(i);
    }
// #############################################

    public void removeStation( Station t )
    {
        int i = this.getStationIndex( t );
        this.Stations.remove(i);
    }

// #############################################

    public int getTrainIndex(Train t)
    {
        for (int k=0; k < this.Trains.size(); k++)
        {
            if (t == this.Trains.get(k)) return(k);
        }
        return(-1);
    }

// #############################################

    public int getStationIndex(Station t)
    {
        for (int k=0; k < this.Stations.size(); k++)
        {
            if (t == this.Stations.get(k)) return(k);
        }
        return(-1);
    }

// #############################################

    public Station getStation(String id)
    {
        for (int k = 0; k < this.Stations.size(); k++)
        {
            Station t = this.Stations.get(k);
            if( id.equals(t.id) ) return(t);
        }
        return null;
    }

// #############################################

    public Station getStation(int index)
    {
        return this.Stations.get(index);
    }

// #############################################

    public Train getTrain(int index)
    {
        return this.Trains.get(index);
    }


// #############################################

    public Train getTrain(String id)
    {
        for (int k = 0; k < this.Trains.size(); k++)
        {
            Train t = this.Trains.get(k);
            if( id.equals(t.id) ) return(t);
        }
        return null;
    }
// #############################################

    public Train createTrain(String id, String name, String from, String to, String stops)
    {
        if ( getTrain(id) != null)  throw new IllegalArgumentException("Train already exists");

        Train t = new Train(id,name);
        t.setStops(from, to , stops, this.Stations);
        this.Trains.add(t);
        return(t);
    }

// #############################################

    public Station createStation(String id, String name)
    {
        if ( getStation(id) != null)  throw new IllegalArgumentException("Station already exists");
        Station t = new Station(id,name);
        this.Stations.add(t);
        return(t);
    }

// #############################################
    public ArrList<Integer> getTrainsStopsCout()
    {
        ArrList<Integer> res = new ArrList<>();

        for (int k = 0; k < this.Trains.size(); k++)
        {
            res.add( this.Trains.get(k).getStopsCount() );
        }
        return res;
    }


// #############################################

    public int compareTrainsByStops(String t1ID, String t2ID)
    {
        Train t1 = this.getTrain(t1ID);
        Train t2 = this.getTrain(t2ID);

        return compareTrainsByStops(t1, t2);
    }


    public int compareTrainsByFirstStation(String t1ID, String t2ID)
    {
        Train t1 = this.getTrain(t1ID);
        Train t2 = this.getTrain(t2ID);

        return compareTrainsByFirstStation(t1, t2);
    }

// #############################################

    public int compareTrainsByStops(Train t1, Train t2)
    {
        return t1.getStopsCount() - t2.getStopsCount();
    }


    public int compareTrainsByFirstStation(Train t1, Train t2)
    {
        return t1.stops.get(0).name.compareTo( t2.stops.get(0).name );
    }

// #############################################

    public ArrList<Train> sortTrainsByStopsCout()
    {
        ArrList<Train> arr = this.getTrains();

        for (int i = 1; i < this.Trains.size(); ++i) {
            Train key = arr.get(i);
            int j = i - 1;
            while (j >= 0 && compareTrainsByStops(arr.get(j), key) > 0 ) {
                arr.set(j + 1, arr.get(j));
                j = j - 1;
            }
            arr.set(j + 1, key);
        }

        return arr;
    }


// #############################################

    public ArrList<Train> sortTrainsByFirtsStation()
    {
        ArrList<Train> arr = this.getTrains();

        for (int i = 1; i < this.Trains.size(); ++i) {
            Train key = arr.get(i);
            int j = i - 1;
            while (j >= 0 && compareTrainsByFirstStation( arr.get(j), key ) > 0) {
                arr.set(j + 1, arr.get(j));
                j = j - 1;
            }
            arr.set(j + 1, key);
        }

        return arr;
    }


// #############################################

    public Train isThereTrain(Station from, Station to)
    {
        for (int k = 0; k < this.Trains.size(); k++){
            Train t = this.Trains.get(k);
            if (t.passBy(from.id) &&  t.passBy(to.id) && t.getStopIndex(from) < t.getStopIndex(to)) return t;
        }
        return null;
    }
// #############################################

    public ArrList<routeSegment> getRoute(Station from, Station to)
    {
        ArrList<routeSegment> res = new ArrList<routeSegment>();
        ArrList<Train> tr1 = this.trainsByStation(from.id);
        ArrList<Train> tr2 = this.trainsByStation(to.id);

        Station change = new Station();
        Train t1 = new Train();
        Train t2 = new Train();

        Train t = this.isThereTrain(from,to);
        if ( t != null )
        {
            routeSegment s = new routeSegment(t);
            s.train = t;
            for (int k = t.getStopIndex(from); k <= t.getStopIndex(to); k++)
            {
                s.stops.add(t.stops.get(k));
            }
            res.add(s);
            return res;
        }

        outerloop:
        for(int k = 0; k < tr1.size(); k++)
        {
            for(int l = 0; l < tr2.size(); l++)
            {
                ArrList<Station> cs = this.commonStation( tr1.get(k), tr2.get(l) );
                for(int m = 0; m < cs.size(); m++)
                {
                    if ( tr1.get(k).getStopIndex(from) <= tr1.get(k).getStopIndex(cs.get(m)) &&
                         tr2.get(l).getStopIndex(to) > tr2.get(k).getStopIndex(cs.get(m))
                        )
                    {
                        change = cs.get(m);
                        t1 = tr1.get(k);
                        t2 = tr2.get(l);
                        break outerloop;
                    }
                }
            }
        }

        if(change.id == null) return null;

        routeSegment s1 = new routeSegment(t1);
        for(int k = t1.getStopIndex(from); k <= t1.getStopIndex(change); k++)
        {
            s1.addStop( t1.stops.get(k));
        }

        res.add(s1);

        routeSegment s2 = new routeSegment(t2);
        for(int k = t2.getStopIndex(change); k <= t2.getStopIndex(to); k++)
        {
            s2.addStop( t2.stops.get(k));
        }

        res.add(s2);
        return res;
    }

// #############################################

    public int checkTrainData(String from, String to, String stops)
    {
        if ( this.getStation(from) == null ) return -1;
        if ( this.getStation(to) == null ) return -2;

        List<String> ss = Arrays.asList(stops.split(":"));
        for (int k = 0; k < ss.size(); k++)
        {
            if (this.getStation(ss.get(k)) == null) return k+1;
        }
        return 0;
    }


}
