/**
 * 
 */
/**
 * 
 */
module Trains2 {
	requires java.desktop;
}